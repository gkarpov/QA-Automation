﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SeleniumWebDriverFirstTests.Models
{
    public class DemoExcel
    {
        public string Name { get; set; }

        public string Age { get; set; }

        public string JobTitle { get; set; }
    }
}

