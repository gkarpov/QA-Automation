﻿namespace SeleniumWebDriverFirstTests
{
    internal class LogEntries
    {
    }
}