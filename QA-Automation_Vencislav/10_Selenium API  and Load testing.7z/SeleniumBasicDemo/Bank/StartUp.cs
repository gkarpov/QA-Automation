﻿namespace Bank
{
    public static class StartUp
    {
        public static void Main()
        {
        }
    }
}
