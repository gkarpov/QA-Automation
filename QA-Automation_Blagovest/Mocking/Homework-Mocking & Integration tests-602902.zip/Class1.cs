﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logintest
{
    public class MyFirstTest
    {
        IWebDriver driver = new OpenQA.Selenium.Chrome.ChromeDriver();
        [Test]
        public void myFirstTest()
        {
            driver.Navigate().GoToUrl("https://www.emag.bg/homepage");
            IWebElement searchItemName = driver.FindElement(By.Id("searchboxTrigger"));
            searchItemName.Clear();
            searchItemName.SendKeys("Тостер Star-Light TS-800W");
            IWebElement searchIcon = driver.FindElement(By.XPath("//*[@id=\"masthead\"]/div/div/div[2]/div/form/div[1]/div[2]/button[2]"));
            searchIcon.Click();
            IWebElement addBasket = driver.FindElement(By.XPath("//*[@id=\"card_grid\"]/div[1]/div/div/div[3]/div[3]/form/button"));
            addBasket.Click();
            driver.FindElement(By.LinkText("виж количката")).Click();
            IWebElement checkProduct = driver.FindElement(By.XPath("//*[@id=\"vendorsContainer\"]/div/div[1]/div/div[2]/div[1]/div[1]/a"));
            StringAssert.Contains("Тостер Star-Light TS-800W", actual: checkProduct.Text, message: "Test Failed");
            driver.Quit();
        }
    }
}
