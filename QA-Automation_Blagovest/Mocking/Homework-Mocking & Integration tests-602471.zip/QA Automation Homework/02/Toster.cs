﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private object card_grid;
        private object frame;

        [TestMethod]
        public void TestMethod1()
        {
            using (var driver = new ChromeDriver())
            {

                driver.Manage().Window.Maximize();
                driver.Navigate().GoToUrl("http://emag.bg");

                IWebElement mainPage = driver.FindElement(By.LinkText("Към началната страница"));
                mainPage.Click();

                IWebElement searchField = driver.FindElement(By.Id("searchboxTrigger"));
                searchField.Clear();
                searchField.SendKeys("Тостер Star-Light TS-800W");

                IWebElement searchButton = driver.FindElement(By.CssSelector("#masthead > div > div > div.navbar-searchbox > div > form > div.input-group.searchbox-input > div.input-group-btn > button.btn.btn-default.searchbox-submit-button"));
                searchButton.Click();


                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("card_grid"))).Click();

                IWebElement openProduct = driver.FindElement(By.XPath("//*[@id=\"card_grid\"]/div[1]/div/div/div[1]/div[1]/a"));
                openProduct.Click();


                IWebElement addToBasket = driver.FindElement(By.CssSelector("#main-container > section:nth-child(1) > div > div:nth-child(2) > div.col-sm-5.col-md-7.col-lg-7 > div > div > div.col-sm-12.col-md-6.col-lg-5 > form > div.product-highlight.product-page-actions > button.btn.btn-primary.btn-emag.btn-block.yeahIWantThisProduct.btn-xl.gtm_680klw.font-size-base > i"));
                addToBasket.Click();


                IWebElement openBasket = driver.FindElement(By.LinkText("виж количката"));
                openBasket.Click();


                IWebElement IsInTheBasket = driver.FindElement(By.XPath("//*[@id=\"vendorsContainer\"]/div/div[1]/div/div[2]/div[1]/div[1]/a"));
                Assert.IsTrue(IsInTheBasket != null);


            }
        }
    }
}
